# physicslab
This repository contains the code used in physics lab.
